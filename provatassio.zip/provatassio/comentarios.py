class Comentarios:
    def __init__(self, id, nome, chefe ,comentario):
        self.__id = id
        self.__nome = nome
        self.__chefe = chefe
        self.__comentario = comentario
        
    def get_id(self):
        return self.__id

    def get_nome(self):
        return self.__nome

    def get_chefe(self):
        return self.__chefe

    def get_comentario(self):
        return self.__comentario