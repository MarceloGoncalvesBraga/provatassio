

from flask import Flask, redirect,render_template, url_for
from restaurante import Restaurante

app = Flask(__name__)

endereco = Endereco(1, 1, "Rj 127", "Bnh", "Paracambi")

lista = [
     Restaurante(1,"Toca da Traira","01.jpg","Rj 127 12000 Paulo de Frontim","Luiz Gustavo","Comer Pode ser melhor")
     Restaurante(2,"Restaurante Caipirao","02.jpg","Rj 127 120 Paracambi","Luiz Gustavo","Comer Pode ser melhor")
     Restaurante(3,"Restaurante da Rute","03.jpg","Rj 127 Centro Paracambi","Luiz Gustavo","Comer Pode ser melhor")
     Restaurante(4,"Alto da Serra Restaurante da Traira","04.jpg","Rj 127 12000","Luiz Gustavo","Comer Pode ser melhor")
     Restaurante(5,"Silva Restaurante","05.jpg","Rj 127 12000","Luiz Gustavo","Comer Pode ser melhor")

]

debug(True)

@app.route("/")
@app.route("/home")
def home():
    template_name = 'home.html'

    return render_template(template_name,
        restaurantes=lista
    )

@app.route("/restaurante/<int:id>")
def exibir_restaurante(id):
    for restaurante in lista:
        if restaurante.get_id() == id:
            return render_template("exibir.html",
                restaurante=restaurante,
                )
            
    return render_template("home.html", restaurantes=lista)





#if __name__ == '__main__':
    #app.run(debug=True) 